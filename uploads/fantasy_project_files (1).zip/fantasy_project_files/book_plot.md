**BOOK_PLOT.txt**

---

**Title**: *The Vestige Mark*

**Tone**: Dark-academia fantasy with humour and dread — think *Zodiac Academy* meets *Spellshadow Manor* with a touch of *Nevernight* cynicism.

---

## ACT I – THE MARK AND THE TAKING

- **Setup**: 18-year-old **Kael Revenhart**, a sarcastic, damaged orphan working as a gravehand in Threndyll, starts experiencing vivid dreams of gods, shadows, and blood. One night, during a thunderstorm, a glowing sigil appears on his skin.

- **Inciting Incident**: A Seeker from **Hollowwood Academy** kidnaps Kael in the dead of night. He’s told he has magical potential and must be trained—or be consumed by the very magic inside him.

- **Complications**: Kael meets other marked students, all bitter, broken, or dangerous. He discovers Hollowwood is a prison as much as a school, filled with forbidden wards, secret duels, and whispers of something beneath the ground.

---

## ACT II – TRIALS AND TREACHERY

- **Rising Conflict**: Students are forced through deadly magical trials called *The Scourings*, where failure means death—or something worse. Kael’s Vestige mark begins to change him, granting power but distorting his memories.

- **Turning Point**: Kael learns the academy isn't just training them—it’s *using* them to locate a lost **Vestige** buried beneath the school. Worse, his mother—thought long dead—might’ve been the last Vestige-bearer, and Kael was born from her cursed blood.

- **Midpoint Crisis**: After a classmate dies, Kael tries to escape but is dragged into a nightmare realm beneath Hollowwood. He sees fragments of future apocalypses and hears the voice of a god.

---

## ACT III – DESCENT AND ASCENT

- **Climax Setup**: Kael returns changed. Hardened. The final Scouring begins—this time, not in illusion, but in the collapsing ruins of the lower vaults. Hollowwood is falling apart as the sealed Vestige awakens.

- **Climax**: Kael must decide between binding the Vestige to himself (and losing who he is) or letting it fall into the Pale Church’s hands. His choice unravels the wards holding Hollowwood together.

- **Resolution**: The academy is half-destroyed. Kael and a few survivors escape into the wilds of Threndyll. The final line: *"I didn’t ask for power. But now that I have it, I’ll burn the gods who left us behind."*

---

