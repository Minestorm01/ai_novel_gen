**CHAPTER_OVERVIEWS.txt**

---

**CHAPTER 1 — The Gravehand**
- *Goal*: Establish Kael’s grim life and introduce the mark.
- *Main Events*: Kael works late in a cemetery. Has visions. The sigil appears. He’s abducted.
- *Word Count*: 4,000–5,000
- *Hook Ending*: *“The next time I opened my eyes, the fog had a face—and it knew my name.”*

**CHAPTER 2 — Hollowwood’s Gates**
- *Goal*: Orientation to Hollowwood. First glimpse of other students.
- *Main Events*: Kael arrives dazed. Meets Headmaster Verren. Sees strange rules and weirder students.
- *Word Count*: 4,500

**CHAPTER 3 — Blood on Stone**
- *Goal*: First Scouring Trial.
- *Main Events*: Forced into a magical combat maze. Kael unleashes uncontrollable magic. Nearly kills another student.
- *Word Count*: 5,000

**CHAPTER 4 — The Scriptorium Lies**
- *Goal*: Introduce school dynamics, cliques, and library secrets.
- *Main Events*: Kael sneaks into restricted section. Meets Riven. Finds book about Vestiges.
- *Word Count*: 4,000

**CHAPTER 5 — Of Fire and Flesh**
- *Goal*: Explore Kael’s growing instability.
- *Main Events*: A second student is hurt. Kael’s mark pulses violently. Begins hallucinating.
- *Word Count*: 4,500

**CHAPTER 6 — The Mask of Light**
- *Goal*: Explore the Pale Church’s involvement.
- *Main Events*: Inquisition visits Hollowwood. One student is taken. Kael is interrogated.
- *Word Count*: 5,000

**CHAPTER 7 — Root Rot**
- *Goal*: Introduce forbidden magic.
- *Main Events*: Kael finds a hidden ritual room. Riven teaches him Hemocraft basics. They bond.
- *Word Count*: 4,200

**CHAPTER 8 — The Waking Grave**
- *Goal*: Reveal Kael’s mother’s secret.
- *Main Events*: A ghost speaks to Kael. She knew his mother. Hollowborn attack.
- *Word Count*: 5,000

**CHAPTER 9 — Broken Bonds**
- *Goal*: Betrayal by a friend.
- *Main Events*: Another student sells Kael out. He’s imprisoned beneath the academy.
- *Word Count*: 4,000

**CHAPTER 10 — The Dream-Eater**
- *Goal*: Delve into Kael’s mind and magic.
- *Main Events*: Tortured by a Dream-Eater. Learns his Vestige connects to a god.
- *Word Count*: 5,200

**CHAPTER 11 — Severance**
- *Goal*: Escape and confrontation.
- *Main Events*: Kael and Riven break free. Destroy part of the academy’s foundation.
- *Word Count*: 5,000

**CHAPTER 12 — The Scouring Deep**
- *Goal*: Begin final trial.
- *Main Events*: Group descends into the forgotten vaults.
- *Word Count*: 4,800

**CHAPTER 13 — Truth Bleeds**
- *Goal*: Reveal the true purpose of Hollowwood.
- *Main Events*: Find relics, recordings, and a dying god.
- *Word Count*: 5,000

**CHAPTER 14 — Vestige-Bound**
- *Goal*: Climax build.
- *Main Events*: Kael merges with the Vestige. Nearly loses his identity.
- *Word Count*: 5,200

**CHAPTER 15 — Ruin**
- *Goal*: Final battle.
- *Main Events*: Hollowwood collapses. Pale Church arrives. Major deaths.
- *Word Count*: 5,500

**CHAPTER 16 — Ash and Fog**
- *Goal*: Aftermath.
- *Main Events*: Survivors flee. Kael confronts Riven about his destiny.
- *Word Count*: 3,500
- *Hook Ending*: *“We didn’t survive because we were strong. We survived because something darker wanted us alive.”*

---

