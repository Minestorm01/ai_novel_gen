**CHARACTERS.txt**

---

### KAEL REVENHART
- **Role**: Protagonist
- **Physical**: Tall, lean, messy black hair, pale grey eyes, a faint scar over his left eyebrow. Vestige mark glows along his right arm.
- **Personality**: Sarcastic, guarded, vengeful, often detached. Uses humour to hide trauma.
- **Motivations**: Discover the truth about his past. Survive Hollowwood. Avoid being consumed by the Vestige within.
- **Secrets**: His mother was a Vestige-bearer. He may not be entirely human.

### RIVEN MORROW
- **Role**: Rogue student, Kael’s closest ally
- **Physical**: Short, wiry, ink-black skin with shifting tattoos, sharp smile, wears bone charms.
- **Personality**: Cunning, curious, emotionally detached but loyal when it matters.
- **Motivations**: Wants to destroy the Pale Church. Believes Kael is a key to unlocking a buried god.
- **Secrets**: Is half-Hollowborn and technically illegal.

### HEADMASTER VERREN
- **Role**: Head of Hollowwood Academy
- **Physical**: Elderly, with piercing golden eyes, always seen in deep green robes. Moves like he’s decades younger.
- **Personality**: Enigmatic, commanding, veiled in riddles. Seems to favour Kael.
- **Motivations**: Reawaken the Vestige. Believes it will restore divine balance.
- **Secrets**: Was a member of the Obsidian Concord.

### LIRA ASHVALE
- **Role**: Rival student
- **Physical**: Blonde with ash-coloured eyes, wears high-collared uniforms, walks like a noble.
- **Personality**: Proud, intelligent, ruthless.
- **Motivations**: Rise through Hollowwood’s ranks. Outshine Kael. Gain power.
- **Secrets**: Her family is deeply embedded in the Pale Church.

### SYLAS WREN
- **Role**: Pale Church Inquisitor
- **Physical**: Burn-scarred face, golden armour etched with runes, white-blonde hair.
- **Personality**: Fanatical, cold, merciless. A true believer.
- **Motivations**: Cleanse Elarion of forbidden magic.
- **Secrets**: Hears a divine voice that may be a remnant of a god—or something else.

### ELLENYA THE BONEKEEPER
- **Role**: Teacher of Necromancy
- **Physical**: Always hooded, skeletal hand visible, robes stitched from shadow-silk.
- **Personality**: Stern, cryptic, oddly nurturing.
- **Motivations**: Teach students control. Prevent them from making the same mistakes she did.
- **Secrets**: Died once. Bargained with death to return.

---

