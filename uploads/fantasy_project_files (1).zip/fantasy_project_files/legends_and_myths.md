**LEGENDS_AND_MYTHS.txt**

---

## 1. **The Sundering of the Sky**
Long ago, when the gods still walked the earth, they split the firmament to seal away a rogue star-spirit named **Vaelrix**. It is said the crack still bleeds starlight, and those who dream beneath it go mad—or become prophets. Some believe Hollowwood sits directly beneath this scar.

## 2. **The Mourning Bride**
A legend from the Mireholds. A witch whose lover was slain by the Pale Church carved her grief into a spell and cursed her own reflection to walk the world, murdering inquisitors. They say she still appears in mirrors near deathbeds, whispering a single word: *"Trade?"*

## 3. **The Hollow Pact**
An unspoken truth passed through forbidden texts: Hollowborn were not built by mortals, but gifted by a dying god to keep balance after the Sundering. One day, a Hollowborn will awaken the god-heart buried in the world's crust.

## 4. **The Severed Saint**
A child born with no face, marked only by glowing hands. She was torn apart by kings afraid of prophecy, but her bones refused to rot. Each piece is buried in a different region—if reassembled, she will judge the world anew.

## 5. **The Vestige That Weeps**
A relic said to cry molten blood when its bearer lies. It's believed to be a piece of a god’s heart. Many rulers have tried to wield it. All were overthrown within days.

---

