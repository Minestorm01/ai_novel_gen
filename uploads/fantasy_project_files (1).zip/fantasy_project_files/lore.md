**LORE.txt**

---

## 🌌 WORLD HISTORY

The realm of **Elarion** is ancient, scarred by magic, war, and betrayal. Over five thousand years ago, the gods walked among mortals, shaping continents with storms and fire. But when mortals grew ambitious, they turned divine gifts against each other. The gods vanished—or were slain—and left their power behind in broken fragments known as **Vestiges**.

Three great empires rose and fell: the flame-worshipping **Vantari Dominion**, the scholar-priests of **Lyrrenhal**, and the necrotic **Obsidian Concord**. Each tried to harness Vestiges for dominion. Each was ultimately devoured by their own hubris.

Now, in the Era of Ashen Light, Elarion is fractured into kingdoms, cults, and free cities. Peace is a lie—everyone is just waiting for the next Vestige to resurface.

---

## 🗺 MAJOR REGIONS

**1. Threndyll** – Fog-drenched, forest-choked, and crawling with shadowcreatures. Known for its brooding castles, curse-breakers, and the infamous **Hollowwood Academy**.

**2. Solandor** – A sun-bleached desert nation ruled by a triumvirate of immortal god-queens. Sacred tombs, glass cities, and memory-drinking sands.

**3. Arkenthia** – Mountain kingdom of warrior-kings, where bloodlines are currency. Steel meets spellcraft. Hostile to mages.

**4. Varrowmere** – Once the seat of the Obsidian Concord. Now a dead zone filled with bone-choked ruins and haunted skies.

**5. The Mireholds** – Swampy free territories governed by warlocks and witches. Lawless, twisted, and utterly unpredictable.

---

## 🧬 SPECIES

- **Humans** – Most populous. Adaptable, ambitious, and often foolish.
- **Velari** – Ethereal beings with shadow-touched souls. Can manipulate emotion and thought but burn through lifespans fast.
- **Dravari** – Scale-skinned descendants of drakes. Honour-bound, ancient, and feared.
- **Myrfolk** – Amphibious tricksters of the Drowned Reaches. Worship sea-spirits.
- **Hollowborn** – Artificial constructs made by mages. Some gained sentience. Their existence is illegal.

---

## 🕯 INSTITUTIONS

**Hollowwood Academy** – A remote academy in Threndyll, shielded by ancient wards and draped in endless fog. It teaches only the magically inclined—but entry is not voluntary. At 18, magical signatures flare, and the marked are claimed by Hollowwood’s Seekers. No one refuses. No one returns the same.

**The Pale Church** – Zealots of light and fire. They hunt dark magic, hoard relics, and manipulate kings through prophecy.

**Guild of Whispered Quills** – Assassins and archivists. They believe true power lies in secrets.

**Order of the Severed Root** – Rogue nature-witches who believe the world is meant to rot. Terrorists. Cultists. Or saviours, depending who you ask.

**The Throne Unseen** – A shadow court said to control the fates of entire cities without ever being seen.

---

## 🔮 TYPES OF MAGIC

See MAGIC_SYSTEM.txt for full breakdown, but common categories include:
- Elementalism (fire, water, air, earth)
- Hemocraft (blood magic)
- Memory magic
- Necromancy
- Glamour & Illusion
- Curse-weaving
- Relic-binding (artifact manipulation)

Some forms, like necromancy or memory siphoning, are considered **forbidden** by The Pale Church—but secretly practiced even at Hollowwood.

---

## 📖 COMMON KNOWLEDGE

- The gods are dead, but their **Vestiges** still warp reality.
- Hollowwood students are forbidden to speak of what happens in their dreams.
- Every time a new Vestige is unearthed, a kingdom falls.
- There is always a new war brewing in the shadows.
- Everyone wants power. Only fools ask why.

---

