**MAGIC_SYSTEM.txt**

---

## CORE PRINCIPLES
Magic in Elarion is drawn from broken divine remnants called **Vestiges**—shards of godhood left behind when the pantheon fell. Some people are born ‘Marked’, others awaken their abilities violently at 18.

Magic is split into schools, each with distinct rules. All magic slowly corrupts the user over time—physically, mentally, or spiritually. The more powerful the spell, the deeper the cost.

---

## SCHOOLS OF MAGIC

**1. Elementalism** – Fire, Water, Air, Earth. Standard but still deadly. Practitioners are often required to wear glyph-bound limiters.

**2. Hemocraft** – Blood magic. Draws power from self or others. Used in rituals, sacrifices, and bindings. Addictive.

**3. Necromancy** – Forbidden. Deals with souls, reanimation, and memories of the dead. Necromancers often become spiritually brittle.

**4. Glamour & Illusion** – Sensory distortion. Used in manipulation, espionage, and seduction. Prolonged use can fracture perception.

**5. Memorycraft** – Extract, overwrite, or consume memories. Rare and feared. Traces of stolen memories often resurface.

**6. Curse-Weaving** – Attach lingering effects to people or places. Not easily reversed. The more complex the curse, the more it clings to its caster.

**7. Relic-Binding** – Magic channelled through ancient objects. Vestiges amplify this art but often contain semi-conscious wills.

---

## LIMITATIONS

- **Magical Exhaustion**: Overuse leads to collapse or coma.
- **Casting Anchors**: Most spells require verbal cues, hand sigils, or blood glyphs.
- **Warding Runes**: Used to prevent or suppress magic in areas like Hollowwood.
- **Corruption**: Magic slowly warps personality or body, often unpredictably.

---

## HOW IT'S ACQUIRED

- **The Marked**: At 18, magical potential manifests, tracked by institutions like Hollowwood.
- **Vestige Exposure**: Proximity to a divine shard can awaken latent abilities.
- **Bloodlines**: Magic often skips generations but runs stronger in certain lineages.

---

## ARTIFACTS

**Vestiges** – Divine remnants. Wild, volatile, semi-sentient. Some bond to hosts, others destroy them.

**Sigil Rings** – Personal magical limiters worn by students. Breakable under duress.

**The Hollowwood Seal** – A master ward beneath the academy that keeps something buried… and silent.

---

