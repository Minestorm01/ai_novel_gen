**MAP_DESCRIPTIONS.txt**

---

## 📍 THRENDYLL
A haunting land of twisted forests and perpetual dusk, where mist slinks through dead trees and abandoned ruins hum with residual spells. Villages huddle close to ancient wards, and travellers stick to moonlit paths. Hollowwood Academy rises like a wound from the hills—wreathed in fog, its towers grown from stone and bone.

## ☀️ SOLANDOR
Vast golden dunes stretch endlessly, broken only by obsidian pyramids and cities woven from heatglass. The sun never sets fully here, and shadows move independently. Water is sacred, sold in vials more precious than gold. Statues of the Triumvirate Queens weep fire during eclipses.

## 🛡 ARKENTHIA
Jagged mountain ranges split the land into valleys ruled by clan-lords and warriors. Castles of granite and iron loom over bloody training fields. Magic is seen as weakness here—except when used to kill. The skies are patrolled by wind-wyrms bred for battle.

## ☠️ VARROWMERE
Once a paradise of knowledge, now a rotting husk. Skeletons litter cities where the dead still mutter. Trees bleed sap the colour of ash. Ruined temples glow with necrotic sigils, and time itself seems fractured. Most maps mark it with a warning: *"DO NOT ENTER—BY ORDER OF ALL CROWNS."*

## 🌿 THE MIREHOLDS
A swampy labyrinth of fungal spires, sinking towns, and root-choked rivers. Magic grows wild here—literally. Spells left unattended might sprout into screaming vines or sentient bogs. Locals barter in curses and brew potions that melt memory. Each Mirehold is its own world, its own madness.

---

