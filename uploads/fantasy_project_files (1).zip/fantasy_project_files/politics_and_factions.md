**POLITICS_AND_FACTIONS.txt**

---

## GOVERNANCE STRUCTURE

Elarion has no central ruler. Power lies fractured among regional warlords, mage-princes, and old bloodlines. Treaties shift like sand.

**Threndyll** – Governed by the **Circle of Veilwood**, a council of wardens and witches. Secretive, mistrustful of outsiders.

**Solandor** – Controlled by the **Triumvirate of Flame**, three immortal queens bound by pact and prophecy.

**Arkenthia** – Ruled by martial clans. The **Steel Accord** elects one High Warden every seven years. Magic is regulated.

**Varrowmere** – Technically lawless. Claimed by no crown. Roamed by relic-hunters, warbands, and the undead.

**The Mireholds** – Each swamp-city answers to a different warlock-pact. Unified only by the **Mire Tribunal** when facing external threats.

---

## FACTIONS

### 🔥 The Pale Church
- **Type**: Theocratic Inquisition
- **Goal**: Eradicate forbidden magic, reclaim divine order.
- **Method**: Public burnings, secret purges, divine auguries.
- **Base**: Cathedral of Embers, Solandor.

### 🐍 The Order of the Severed Root
- **Type**: Eco-terrorist coven
- **Goal**: Return Elarion to primal balance.
- **Method**: Curse-plagues, living forest infestations, blood offerings.
- **Base**: Rootspire, hidden in the Mireholds.

### 🦉 Guild of Whispered Quills
- **Type**: Secretive intelligence guild
- **Goal**: Record and control all knowledge.
- **Method**: Spymasters, soul-contracts, memory-theft.
- **Base**: Mobile. Their headquarters is a walking citadel.

### 🗡 The Hollowborn Network
- **Type**: Underground resistance
- **Goal**: Free Hollowborn and magical constructs from persecution.
- **Method**: Sabotage, arcane grafting, refugee relocation.
- **Base**: Unknown. Possibly within Hollowwood itself.

---

## SHADOW GROUPS

- **The Throne Unseen** – A shadow court said to control events behind major thrones.
- **The Gilded Moth** – A noble-run black market dealing in magical slavery and relics.

---

