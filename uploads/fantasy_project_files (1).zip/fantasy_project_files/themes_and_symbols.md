**THEMES_AND_SYMBOLS.txt**

---

## CORE THEMES

**1. Identity and Corruption**
Kael's struggle reflects the tension between who we are and what we become when given power. Every choice he makes slowly alters who he is—some parts lost, others born.

**2. Found Family vs. Blood Legacy**
The bonds Kael forms inside Hollowwood contrast his grim heritage. Riven, Lira, and others become mirrors—showing what he could be, or warning what he might become.

**3. Power, Faith, and Control**
The Pale Church’s zealotry vs. Hollowwood’s secret rituals highlight the manipulations behind every 'truth'. Magic and religion are both forms of control—whether by force, faith, or fear.

**4. Death as Catalyst, Not End**
From necromancy to ancient myths, death in this world isn't a full stop. It's a comma—marking the shift to something darker, deeper, more dangerous.

---

## SYMBOLS & MOTIFS

**The Vestige Mark** – Appears on Kael's skin, mutating as the story progresses. Symbolises both curse and potential.

**Fog** – Constant in Threndyll and around Hollowwood. Symbol of uncertainty, illusion, and things lurking unseen.

**Bones** – Recurring visual tied to memory, legacy, and death. Kael keeps a bone charm given by Riven.

**Mirrors** – Used in magic, myths, and dreams. Often show what characters fear becoming—or deny they already are.

**Blood and Ink** – Linked through Hemocraft and Riven’s spell tattoos. Represent sacrifice, truth, and permanence.

---

